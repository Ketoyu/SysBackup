﻿using System.Collections.Generic;
using QuodLib.Linq;

namespace SysBackup {
    public class SuperStack<T>
	{
		Stack<Stack<T>> mother = new Stack<Stack<T>>();
		Stack<T> child = new Stack<T>();

		public SuperStack() {}
		public void Push(T obj)
		{
			if (child.Count < int.MaxValue) child.Push(obj);
			else {
				mother.Push(child);
				child = new Stack<T>();
				child.Push(obj);
			}
		}
		public T Pop()
		{
				if (child.IsEmpty()) {
				if (mother.IsEmpty()) return default(T);
				else
					child = mother.Pop();
				}

				return child.Pop();
		}
		public bool IsEmpty()
		{
			return child.IsEmpty() && mother.IsEmpty();
		}
	}
}
