﻿using System;

namespace IOCL {
    public readonly record struct ErrorModel(string Title, string Path, Exception Error);
}
