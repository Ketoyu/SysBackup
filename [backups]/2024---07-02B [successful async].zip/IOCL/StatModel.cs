﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCL {
	public readonly record struct StatModel(string Status, bool Working);
}
