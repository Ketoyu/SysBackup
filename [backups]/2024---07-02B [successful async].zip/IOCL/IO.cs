﻿using QuodLib.IO.Symbolic;
using Symbolic = QuodLib.IO.Symbolic.Info;
using QuodLib.Strings;
using QuodLib.IO;
using System.Drawing;

namespace IOCL {
    public static class IO {
        public static async Task CopyAsync(string destination, string commonPath, IList<string> sources, IList<string> skipSources, IProgress<StatModel> status, IProgress<string> progress, IProgress<SymbolicLink>? symbolicLink, IProgress<ErrorModel> error, CancellationToken cancel) {
            if (!Directory.Exists(destination))
                throw new ArgumentException($"Directory not found: {destination}", nameof(destination));

            if (!sources.Any())
                throw new ArgumentException($"Empty list", nameof(sources));

            status.Report(new() {
                Status = "analyzing...",
                Working = true
            });

            progress.Report(string.Empty);

            if (cancel.IsCancellationRequested) {
                status.Report(new() {
                    Status = "Canceled",
                    Working = false
                });
                return;
            }

            var analyzis = await Analyze(sources, skipSources, symbolicLink, error, cancel);

            if (cancelled())
                return;

            (List<string> copy, long sizeSource) = analyzis!.Value;

            status.Report(new() {
                Status = "Copying...",
                Working = true
            });

            string s_srcSze = Misc.Size_Compress(sizeSource, 1024, 3, Misc.SizeNames_Bytes, false);

            long sizeDestination = 0;
            IProgress<long> psized = new Progress<long>().OnChange((_, add) => sizeDestination += add);
            IProgress<bool> psub = new Progress<bool>().OnChange((_, success) => {
                if (success)
                    progress.Report($"{Math.Floor(sizeDestination * 100 / (decimal)sizeSource)}%    ({Misc.Size_Compress(sizeDestination, 1024, 3, Misc.SizeNames_Bytes, false)}/{s_srcSze})");
                else
                    progress.Report($"{(Math.Round(sizeDestination / (decimal)sizeSource, 2) * 100)}%    ({Misc.Size_Compress(sizeDestination, 1024, 3, Misc.SizeNames_Bytes, false)}/{s_srcSze})");
            });

            //Copy folders (as empty)
            await Parallel.ForEachAsync(copy, cancel, (itm, pcancel) => {
                string dest = ResolvePath(destination, itm, commonPath);
                bool isDir = Directory.Exists(itm);
                try {
                    if (isDir)
                        Files.Dir_MakeIfNotExist(dest);
                    else {
                        Files.Dir_MakeIfNotExist(Files.Filename_GetPath(dest));
                        Files.File_CopyIfNewer(itm, dest);
                        psized.Report((new FileInfo(itm)).Length);
                        //status.Report(new($"Copying: {cF.Filename_GetPath(itm)}", true));
                    }

                    psub.Report(true);
                } catch (Exception ex) {
                    error.Report(new(isDir ? "Folder" : "File", itm, ex));
                    psub.Report(false);
                }

                return ValueTask.CompletedTask;
            });

            _ = cancelled();

            //---- (local methods) ----

            bool cancelled() {
                if (cancel.IsCancellationRequested) {
                    status.Report(new() {
                        Status = "Canceled",
                        Working = false
                    });
                    return true;
                }

                return false;
            }
        }

        public static string ResolvePath(string destination, string source, string? ignoreCommonPath) {
            string source_ = !string.IsNullOrEmpty(ignoreCommonPath) && source.StartsWith(ignoreCommonPath)
                ? source.GetAfter(ignoreCommonPath)
                : source.FromIndex(3);

            if (source_[0] == '\\' || source_[0] == '/')
                source_ = source_.Substring(1);

            string final = Path.Combine(destination, source_);
            return final;
        }

        private async static Task<(List<string>, long)?> Analyze(IList<string> sources, IList<string> skipSources, IProgress<SymbolicLink>? symbolicLink, IProgress<ErrorModel> error, CancellationToken cancel) {

            Stack<string> stkDirs_init = new();
            IProgress<string> pinit = new Progress<string>().OnChange((_, dir) => stkDirs_init.Push(dir));

            await Parallel.ForEachAsync(sources, cancel, (dir, _) => {
                try {
                    if (Symbolic.TryGet(dir, out SymbolicLink? link) != SymbolicLinkType.None) {
                        symbolicLink?.Report(link!);
                        return ValueTask.CompletedTask;
                    }
                } catch (Exception ex) {
                    error.Report(new("Folder", dir, ex));
                    return ValueTask.CompletedTask;
                }

                pinit.Report(dir);
                return ValueTask.CompletedTask;
            });

            List<string> copy = [];

            IProgress<string> pcopy = new Progress<string>().OnChange((dir_, dir) => copy.Add(dir));

            Stack<string> stkDir_root = new();
            IProgress<string> proot = new Progress<string>().OnChange((dir_, dir) => stkDir_root.Push(dir));

            long size = 0;
            IProgress<long> psize = new Progress<long>().OnChange((_, add) => size += add);

            //nested dir-list
            while (stkDirs_init.Any()) {
                if (cancel.IsCancellationRequested)
                    return null;

                stkDir_root.Push(stkDirs_init.Pop()); //hold one root-dir.

                while (stkDir_root.Any()) //for (that root-dir)
                {
                    if (cancel.IsCancellationRequested)
                        return null;

                    bool isEnd = true;
                    string root = stkDir_root.Pop();

                    //ignore
                    try {
                        if (skipSources.Contains(root))
                            continue;

                        if (Symbolic.TryGet(root, out SymbolicLink? link) != SymbolicLinkType.None) {
                            symbolicLink?.Report(link!);
                            continue;
                        }
                    } catch (Exception ex) {
                        error.Report(new("Folder", root, ex));
                        continue;
                    }

                    //all files
                    try {
                        string[] files = Directory.GetFiles(root);

                        await Parallel.ForEachAsync(files, cancel, (fl, _) => {
                            try {
                                FileInfo fI = new(fl);

                                if (Symbolic.TryGet(fI, out SymbolicLink? link))
                                    symbolicLink?.Report(link!);
                                else {
                                    //Include
                                    psize.Report(fI.Length);
                                    pcopy.Report(fl);
                                }
                            } catch (Exception ex) {
                                error.Report(new("File", fl, ex));
                            }

                            return ValueTask.CompletedTask;
                        });
                    } catch (Exception ex) {
                        error.Report(new("File", root, ex));
                    }

                    //subdirectories
                    try {
                        string[] subdirs = Directory.GetDirectories(root);

                        await Parallel.ForEachAsync(subdirs, cancel, (subdir, _) => {
                            //Ignore symbolic
                            try {
                                if (skipSources.Contains(subdir))
                                    return ValueTask.CompletedTask;

                                if (Symbolic.TryGet(subdir, out SymbolicLink? link) != SymbolicLinkType.None) {
                                    symbolicLink?.Report(link!);
                                    return ValueTask.CompletedTask;
                                } else {
                                    //Include
                                    proot.Report(subdir);
                                    isEnd = false;
                                }
                            } catch (Exception ex) {
                                error.Report(new("File", subdir, ex));
                            }

                            return ValueTask.CompletedTask;
                        });
                    } catch (Exception ex) {
                        error.Report(new("File", root, ex));
                    }

                    if (isEnd)
                        copy.Add(root);
                }
            }

            return (copy, size);
        }

    }
}
